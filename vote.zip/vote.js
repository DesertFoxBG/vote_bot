const Discord = require("discord.js");
const Store = require('data-store');
var splitArray = require('split-array');
const votes = new Store({ path: 'vote.json' });
const client = new Discord.Client();
var hasPole = false;
var hasVoted = false;
var question;
client.on("ready", () => {
  console.log("Bot Active.");
});
client.on('message', function(message) {
	if(message.content.startsWith('!pole')) { // create a pole
		if(message.author !== undefined) {
			if(hasPole === false) {
				question = message.content;
				question = question.replace('!pole ' , '')
				const embed = {
				  "title": question,
				  "description": "@everyone\n!vote UP / !vote DOWN",
				  "color": 1863843,
				  "timestamp": new Date()
				};
				message.channel.send({ embed });
				hasPole = true;
			}
		}
	}else if(message.content.startsWith('!vote UP')) { // voting for pole
		if(message.author !== undefined) {
			if(hasVoted !== true || votes.get(message.author.id).ups === 0) {
				votes.set(message.author.id, {id: message.author.id, ups: 1, downs: 0})
				console.log("UP");
				message.channel.send(message.author + ' voted UP for Pole: ' + question)
			}
		}else{
			message.channel.send('Command incorrect. Usage: !vote UP')
		}
	}else if(message.content.startsWith('!vote DOWN')) { // voting against pole
		if(message.author !== undefined){
			if(hasVoted !== true || votes.get(message.author.id).downs === 0) {
				votes.set(message.author.id, {id: message.author.id, ups: 0, downs: 1})
				console.log("DOWN");
				message.channel.send(message.author + ' voted DOWN for Pole: ' + question)
			}
		}else{
			message.channel.send('Command incorrect. Usage: !vote DOWN')
		}
	}else if(message.content.startsWith('!votes')){ // check votes
		
		// idk
		var data = votes.clone()
		var dArr = []
		var sortArr = []
		Object.keys(data).forEach(function(key) {
			var val = data[key];
			sortArr.push(val)
		});
		sortArr.sort(function (a, b) {
			return (b.ups - b.downs) - (a.ups - a.downs)
		});
		sortArr.forEach(function(val) {
			dArr.push('<@' + val.id + '> | Ups: ' + val.ups + ' | Downs: ' + val.downs + ' | Total: '+(val.ups-val.downs))
		})
		var sArr = splitArray(dArr, 20)
		sArr.forEach(function(page) {
			var pstring = page.join('\n')
			const embed = {
			  "title": "Current votes for: " + question,
			  "description": pstring,
			  "color": 1863843,
			  "timestamp": new Date()
			};
			message.channel.send({ embed });
		})
		if(sArr.length === 0) {
			message.channel.send('No users have voted.')
		}
	}else if(message.content.startsWith('!endpole')) { // end a pole
		
		// idk
		var data = votes.clone()
		var dArr = []
		var sortArr = []
		Object.keys(data).forEach(function(key) {
			var val = data[key];
			sortArr.push(val)
		});
		sortArr.sort(function (a, b) {
			return (b.ups - b.downs) - (a.ups - a.downs)
		});
		console.log(sortArr);
		var total = {
			ups: 0,
			downs: 0
		};
		for(var count = 0; count < sortArr.length; count++) {
			total.ups = total.ups + sortArr[count].ups;
			total.downs = total.downs + sortArr[count].downs;
			total.overall = total.ups - total.downs;
		}
		
		// overall pole result
		if(total.overall === 0) {
			var result = "Draw";
		}else if(total.overall < 0) {
			var result = "No";
		}else{
			var result = "Yes";
		}
		
		// writing to discord chat
		const embed = {
		  "title": question,
		  "description": "UP votes: " + total.ups + "\nDOWN votes: " + total.downs + "\nPole result: " + result,
		  "color": 1863843,
		  "timestamp": new Date()
		};
		message.channel.send({ embed });
		
		hasPole = false;
	}else if(message.content.startsWith('!help')) { // display all commands
		
		// writing to discord chat
		const embed = {
		  "title": "Commands:",
		  "description": "1) !pole <QUESTION> -> start a pole\n2) !vote UP -> vote up for pole\n3) !vote DOWN -> vote down for pole\n4) !endpole -> finish pole",
		  "color": 1863843,
		  "timestamp": new Date()
		};
		message.channel.send({ embed });
	}
})
process.on('unhandledRejection', (reason, p) => {
  console.log('Unhandled Rejection at: Promise', p, 'reason:', reason);
});
client.login("NTMxNDM3MzgwODQ3MjcxOTM2.DxO_hQ.2IOHYTBYQHlHLRm58hc5mjyKjbA");
